import './App.css';
import Chatbot from './pages/ChatBot';
function App() {
  return (
    <div className="App">
      <Chatbot />
    </div>
  );
}

export default App;
