import React, { useState } from 'react';
import axios from 'axios';
import styled from 'styled-components';
import {IoLogoSnapchat} from 'react-icons/io';
import {FaRegUserCircle} from 'react-icons/fa';

const ChatContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: 100vh;
`;
const Error = styled.div`
  color: #f74040;
  font-weight:bold;
`;
const ChatHistory = styled.div`
  flex: 1;
  margin-bottom: 1rem;
  padding: 1rem;
`;

const Message = styled.div`
  margin-bottom: 0.5rem;
  color: #fff;
  border-radius: 20px;
  padding: 30px;
  font-weight:600;

  &.user {
    text-align: left;
    padding-right: 10px;
    background-color: white;
    color: #000;
  }
  &.bot {
    text-align: left;
    background:
        linear-gradient(#636363, transparent),
        linear-gradient(to top left, #636363, transparent),
        linear-gradient(to top right, #a3a3a3, transparent);
    background-blend-mode: screen;
  }
`;
const User = styled.div`
   display: ruby-base;
`;
const Sender = styled.p`
  font-size: 20px;
`;
const TextMessage = styled.p`
  font-size: 15px;
`;
const InputContainer = styled.form`
  display: flex;
  margin:2rem;
  border-bottom: 2px solid #ff997a;
`;

const Input = styled.input`
  flex-grow: 1;
  padding: 0.5rem;
  border: none;
  font-weight:bold;
`;

const Button = styled.button`
  margin-right: .2rem;
  padding: 1rem 2rem;
  border: none;
  border-radius: 0.25rem;
  background-color: #ff997a;
  color: white;
  font-size: 15px;
  font-weight: 600;
`;

export default function Chatbot() {
  const [chatHistory, setChatHistory] = useState([
    {
      message: "Hello. Ask me your questions, Im happy to help ypu",
      sender: "bot",
    },
  ]);
  const [userInput, setUserInput] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!userInput) return;
    sendMessage(userInput);
    setUserInput("");
  };

  const sendMessage = async (message) => {
 
    const maxTokens = 10;
    const temperature = 0.7;
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.REACT_APP_API_KEY}`
    };
    const data = {
      prompt: message,
      max_tokens: maxTokens,
      temperature: temperature,
      model: 'text-davinci-002'
    };
    axios.post('https://api.openai.com/v1/completions', data, {headers})
      .then(response => {
        const answer = response.data.choices[0].text;
        setChatHistory([
            ...chatHistory,
            {
              message: data.prompt,
              sender: "user",
            },
            {
              message: answer,
              sender: "bot",
            },
          ]);
      })
      .catch(error => {
        setError(error.message);
      });
  };

  return (
    <ChatContainer>
      <h1>Chatbot</h1>
      {error&&<Error>Error: {error}</Error>}
      <ChatHistory>
        {chatHistory.map((chat, index) => (
        <Message className={chat.sender} key={index}>
        <User>
          {chat.sender==='bot'&&<IoLogoSnapchat size={20}/>}
          {chat.sender==='user'&&<FaRegUserCircle size={20}/>}
          <Sender>{chat.sender}</Sender>
        </User>
        <TextMessage>
          {chat.message}
        </TextMessage>
       </Message>
        ))}
      </ChatHistory>
      <InputContainer onSubmit={handleSubmit}>
        <Input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Type your message here..."
        />
        <Button type="submit">Send</Button>
      </InputContainer>
    </ChatContainer>
  );
}
